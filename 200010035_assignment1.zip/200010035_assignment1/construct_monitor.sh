make compilecreator
bin/creator.out $1