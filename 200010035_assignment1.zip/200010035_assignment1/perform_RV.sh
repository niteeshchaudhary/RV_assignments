./construct_monitor.sh $1
make compilemonitor
./bin/test_monitor.out $2 $3
